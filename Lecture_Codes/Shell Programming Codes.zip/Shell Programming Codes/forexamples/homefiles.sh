#!/bin/bash
for file in $(ls /home/user)
do
    echo "Processing $file"
done
