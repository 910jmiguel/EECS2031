#!/bin/bash
for fruit in apple banana cherry
do
    echo "I like $fruit"
done


