
// Name of the file : 3_function_multiplefiles.c
//Function Definition
int sum(int i, int j){
    return i + j;
}
//No main function
//No preprocessor statements - no #include