
// Name of the file : 4_function_multiplefiles.c

int result;
//Function Definition
int sum(int i, int j){
    result = i + j;
}
//No main function
//No preprocessor statements - no #include